# Ticket-Booking-System-
Ticket Booking System is made using visual studio code with JS,HTML jquery and CSS here we can book tickets for flights , trains and theatres and ticket is sent as gmail and you can also get a confrimation mail after booking the ticket.

Our website consists of 8 modules 
i) Home ii) Bus Booking iii)TrainBooking iv) Flight Booking V) TheatreBooking Vi)Login Vii) About Us <br>
Viii) Map 

i)Home:- This is the mail module that connects all the modules together , It also has the mail confrimation for login .

![image](https://user-images.githubusercontent.com/66934832/133825310-cc3738f8-f73f-4006-a507-628ec8dff4a1.png)
![image](https://user-images.githubusercontent.com/66934832/133825244-4cd6f5d2-d759-4e86-8d6e-d6982bbf1cf9.png)
![image](https://user-images.githubusercontent.com/66934832/133825332-56860162-06c4-48ba-9b42-7429dff9b664.png)
![image](https://user-images.githubusercontent.com/66934832/140611639-29de73d9-ca30-4025-a550-afe4da2b88df.png)

mail recived 📧 👍 :- 

![image](https://user-images.githubusercontent.com/66934832/140611719-55890dde-2eaf-4d11-848b-e557b40878dd.png)


ii) Flight Bookings : This module allows to book flight ticket with mail 📧 confrimation 
![Screenshot (889)](https://user-images.githubusercontent.com/87609938/140053649-17994159-f8d4-44da-803a-56f5114ef716.png)
![Screenshot (890)](https://user-images.githubusercontent.com/87609938/140053737-8cae0613-f132-4950-955a-35dd661627a2.png)
![Screenshot (891)](https://user-images.githubusercontent.com/87609938/140053797-04bdf76d-0ea4-47b0-9b53-42ac40b2719a.png)
![Screenshot (892)](https://user-images.githubusercontent.com/87609938/140053839-d9dea095-786d-434b-9105-ef60c482589c.png)



iii) Bus Booking : Helps to book Bus ticket . 
![image](https://user-images.githubusercontent.com/66934832/140611831-1b156a3a-cf3c-4ec5-8199-2d727a97f5cd.png)

![image](https://user-images.githubusercontent.com/66934832/140611869-4ec49899-9a40-4788-8fb5-ff7ca3a2f2d0.png)

iV) Train Booking : Allows to book trains .
![image](https://user-images.githubusercontent.com/66934832/140612025-3700d479-a246-4d9b-927a-878bfd898be7.png)
![image](https://user-images.githubusercontent.com/66934832/140612101-cc71c4df-3c36-4394-a617-04d78cb30d88.png)
![image](https://user-images.githubusercontent.com/66934832/140612128-8530e62c-8d69-4e6a-8536-dcd024eb1898.png)
Ticket can also be printed
![image](https://user-images.githubusercontent.com/66934832/140612145-c7960701-c51c-4165-88a9-fd4ca44990ee.png)

V) Theatre Booking : Helps to book Theatre tickets .

![image](https://user-images.githubusercontent.com/66934832/140612176-85a12a11-537b-4986-b6cf-e28f24b58d55.png)
<br>

Vi) Login : Helps to verify users.<br>
![image](https://user-images.githubusercontent.com/66934832/140612233-1e32b6f1-759d-44ec-8867-052a25f7759e.png)

Vii) About us : Has info of the team. <br>
![image](https://user-images.githubusercontent.com/66934832/140612310-509e0faa-002a-4fb0-bb7c-0c6b458a3089.png) <br>
if expand button is clicked it shows detailed version of the team. <br>
![image](https://user-images.githubusercontent.com/66934832/140612370-63885422-9851-450b-9258-d17a2c308d58.png)

Viii) map : Shows the start and end destination.
<br>
![image](https://user-images.githubusercontent.com/66934832/140612476-b0f1eda3-7053-4169-872d-9022d723e424.png)
![image](https://user-images.githubusercontent.com/66934832/140612514-f28f7f3f-7375-42db-8d81-a44add065965.png)

.


